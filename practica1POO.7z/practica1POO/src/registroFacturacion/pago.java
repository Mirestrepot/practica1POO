package registroFacturacion;
public class pago {
    
}
