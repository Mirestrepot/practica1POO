package gestionApp.getionPago;

public class metodoPago {
    
}
