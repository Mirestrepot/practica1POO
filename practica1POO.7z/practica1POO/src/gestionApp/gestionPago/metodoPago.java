package gestionApp.gestionPago;

public class metodoPago {
    
}
