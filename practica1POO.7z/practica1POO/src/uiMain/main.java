package uiMain;
import java.util.Scanner;

import gestionApp.comprasClientes.cliente;
public class main {
    public  main(String[] args) throws Exception {
        
        
		
    }
    
}
